package gomba;

import tekton.Tekton;
import tesztelo.ParancsFeldolgozo;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static tesztelo.Menu.parancsFeldolgozo;

/**
 * Gomba osztály
 *
 * @class Gomba
 *
 * @brief A gombákat reprezentáló osztály
 *
 * @details
 * Ez az osztály felelős a gombák reprezentálásáért, azokkal kapcsolatos műveletek végzéséért.
 * Az osztály tartalmazza a gombatesteket, a gombafonalakat, valamint a gombákkal kapcsolatos műveleteket.
 *
 * @see felhasznalo.Gombasz
 *
 * @note Prototípus állapotban van.
 *
 * @author Blasek
 * @version 2.0
 * @date 2025-04-24
 */
public class Gomba {

    /**
     * A gomba azonosítója
     * @var int id
     * @brief A gomba azonosítóját tároló változó.
     */
    private int id;

    /**
     * Gombafonalak listája
     * @var List<Gombafonal> gombafonalak
     * @brief A gombafonalakat tároló lista.
     */
    private List<Gombafonal> gombafonalak;

    /**
     * Gombatestek listája
     * @var List<Gombatest> gombatestek
     * @brief A gombatesteket tároló lista.
     */
    private List<Gombatest> gombatestek;

    public Gomba(int id) {
        this.id = id;
        this.gombafonalak = new ArrayList<Gombafonal>();
        this.gombatestek = new ArrayList<Gombatest>();
    }

    /**
     * Visszaadja, hogy két tekton közt van-e fonal
     * @return true, ha van fonal, false egyébként
     */
    public boolean fonalOsszekoti(Tekton tekton1, Tekton tekton2) {
        for (Gombafonal gombafonal : gombafonalak) {
            if (gombafonal.getHatar1() == tekton1 && gombafonal.getHatar2() == tekton2) {
                return true;
            }
        }
        return false;
    }

    /**
     * Fonal növesztése két tekton közés, vagy egy darab tektonra (ekkor a másik tekton ugyan az mint az első)
     * @param tekton1 az egyik tekton, amelyen a fonál növekszik
     * @param tekton2 a másik tekton, amelyen a fonál növekszik
     * @param gombatest a gombatest, amelyhez a fonal tartozik
     */
    public void fonalNovesztes(Tekton tekton1, Tekton tekton2, Gombatest gombatest, int fonalid) {
        if (!gombatestek.isEmpty() && !fonalOsszekoti(tekton1, tekton2)) {
            if (tekton1.szomszedosTekton(tekton2) || tekton2.szomszedosTekton(tekton1)) {
                Random rand = new Random();
                boolean validId = false;
                int nextId = 0;
                while (!validId) {
                    nextId = rand.nextInt(100);
                    validId = true;
                    for (Gombafonal gombafonal : gombafonalak) {
                        if (gombafonal.getID() == nextId) {
                            validId = false;
                            break;
                        }
                    }
                }
                Gombafonal gombafonal = new Gombafonal(fonalid, tekton1, tekton2, gombatest);
                parancsFeldolgozo.print("Fonal (" + fonalid + ") Sima elhelyezve Tekton (" + tekton1.getID() + ") Tekton (" + tekton1.getID() + ") Gomba (" + getID() + ") által\n");
                addFonal(gombafonal);
            }
        }
    }

    /**
     * Fonal növesztése két tekton közés, vagy egy darab tektonra (ekkor a másik tekton ugyan az mint az első)
     * @param tekton1 az egyik tekton, amelyen a fonál növekszik
     * @param tekton2 a másik tekton, amelyen a fonál növekszik
     * @param gombatest a gombatest, amelyhez a fonal tartozik
     * @param gombafonal a gombafonal, amelyet hozzáadunk
     */
    public void fonalNovesztes(Tekton tekton1, Tekton tekton2, Gombatest gombatest, Gombafonal gombafonal) {
        if (!gombatestek.isEmpty() && !fonalOsszekoti(tekton1, tekton2)) {
            if (tekton1.szomszedosTekton(tekton2) || tekton2.szomszedosTekton(tekton1)) {
                addFonal(gombafonal);
            }
        }
    }

    /**
     * Fonal hozzáadása
     * @param gombafonal a hozzáadandó fonal
     */
    public void addFonal(Gombafonal gombafonal) {
        parancsFeldolgozo.print("Gomba (" + getID() + ") fonalak értéke megváltozott: ");
        for (int i = 0; i < gombafonalak.size(); i++) parancsFeldolgozo.print("Fonal ("+ gombafonalak.get(i).getID() +")" + (i == gombafonalak.size() - 1 ? " " : ", "));
        parancsFeldolgozo.print("->");
        gombafonalak.add(gombafonal);
        for (int i = 0; i < gombafonalak.size(); i++) parancsFeldolgozo.print(" Fonal ("+ gombafonalak.get(i).getID() +")" + (i == gombafonalak.size() - 1 ? "\n" : ","));
    }

    /**
     * Fonal eltávolítása
     * @param gombafonal az eltávolítandó fonal
     */
    public void removeFonal(Gombafonal gombafonal) {
        parancsFeldolgozo.print("Gomba (" + getID() + ") fonalak értéke megváltozott: ");
        for (int i = 0; i < gombafonalak.size(); i++) parancsFeldolgozo.print("Fonal ("+ gombafonalak.get(i).getID() +")" + (i == gombafonalak.size() - 1 ? " " : ", "));
        parancsFeldolgozo.print("->");
        gombafonalak.remove(gombafonal);
        gombafonal.setPusztulasSzamlalo(-1);
        for (int i = 0; i < gombafonalak.size(); i++) parancsFeldolgozo.print(" Fonal ("+ gombafonalak.get(i).getID() +")" + (i == gombafonalak.size() - 1 ? "\n" : ","));
        if (gombafonalak.isEmpty()) parancsFeldolgozo.print("\n");
    }

    /**
     * Gombatest hozzáadása
     * @return a gombatest
     */
    public void addGombatest(Gombatest gombatest) {
        parancsFeldolgozo.print("Gomba ("+ getID() +") gombatestek értéke megváltozott: ");
        for (int i = 0; i < gombatestek.size(); i++) parancsFeldolgozo.print("Gombatest ("+ gombatestek.get(i).getID() +")" + (i == gombatestek.size() - 1 ? " " : ", "));
        parancsFeldolgozo.print("->");
        gombatestek.add(gombatest);
        for (int i = 0; i < gombatestek.size(); i++) parancsFeldolgozo.print(" Gombatest ("+ gombatestek.get(i).getID() +")" + (i == gombatestek.size() - 1 ? "\n" : ","));
    }

    /**
     * Gombatest eltávolítása
     * @param gombatest az eltávolítandó gombatest
     */
    public void removeGombatest(Gombatest gombatest) {
        parancsFeldolgozo.print("Gomba ("+ getID() +") gombatestek értéke megváltozott: ");
        for (int i = 0; i < gombatestek.size(); i++) parancsFeldolgozo.print("Gombatest ("+ gombatestek.get(i).getID() +")" + (i == gombatestek.size() - 1 ? " " : ", "));
        parancsFeldolgozo.print("->");
        gombatestek.remove(gombatest);
        for (int i = 0; i < gombatestek.size(); i++) parancsFeldolgozo.print(" Gombatest ("+ gombatestek.get(i).getID() +")" + (i == gombatestek.size() - 1 ? "\n" : ","));
    }

    /**
     * Visszaadja a gomba által növesztett gombafonalakat
     * @return a gombafonalak listája
     */
    public List<Gombafonal> getGombafonalak() {
        return gombafonalak;
    }

    /**
     * Visszaadja a gombatesteket
     * @return a gombatestek listája
     */
    public List<Gombatest> getGombatest() {
        return gombatestek;
    }

    public int getID() {
        return id;
    }
}
