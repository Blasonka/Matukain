package interfaces;

/**
 * Interfész a rovar hatás kifejtéséhez.
 */
public interface hatasKifejtes {
    void hatasKifejtes(Object target);
}
