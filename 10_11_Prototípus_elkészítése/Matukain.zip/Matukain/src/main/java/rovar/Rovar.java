package rovar;

import felhasznalo.Gombasz;
import felhasznalo.Rovarasz;
import gomba.Gomba;
import gomba.Gombafonal;
import jateklogika.gameLogic;
import spora.OsztoSpora;
import spora.Spora;
import tekton.Tekton;
import tesztelo.ParancsFeldolgozo;

import java.util.ArrayList;
import java.util.List;

import static tesztelo.Menu.parancsFeldolgozo;

/**
 * Rovar osztály
 *
 * @class Rovar
 *
 * @brief A rovarokat reprezentáló osztály
 *
 * @details
 * Ez az osztály felelős a rovarok reprezentálásáért, azokkal kapcsolatos műveletek végzéséért.
 * Az osztály tartalmazza a tektont, ahol a rovar van, a rovar telítettségét, az elfogyasztott spórákat tároló listát, valamint a rovarokkal kapcsolatos műveleteket.
 *
 * @see felhasznalo.Rovarasz
 *
 * @note Prototípus állapotban van.
 *
 * @author JGeri
 * @version 2.0
 * @date 2025-04-25
 */
public class Rovar {
    /**
     * Rovar tartózkodási helye.
     * @var Tekton tekton
     * @brief Az a tekton, ahol a rovar tartózkodik.
     */
    private Tekton tekton;

    /**
     * Rovar telítettsége.
     * @var int telitettseg
     * @brief A rovar telítettségi szintje számokban megadva.
     */
    private int telitettseg;

    /**
     * Elfogyasztott spórák.
     * @var List<Spora> elfogyasztottSporak
     * @brief Az elfogyasztott spórákat tároló lista.
     */
    private List<Spora> elfogyasztottSporak;

    /**
     * Sebesség.
     * @var int sebesseg
     * @brief A rovar sebessége.
     */
    private int sebesseg;

    /**
     * Vágási lehetőség.
     * @var boolean vaghate
     * @brief A rovar vágási lehetősége.
     */
    private boolean vaghate;

    /**
     * Rovar azonosítója.
     * @var int ID
     * @brief A rovar egyedi azonosítója.
     */
    private int ID;

    /**
     * Default constructor
     * @brief Inicializálja a kezdő tektont, valamint alapértelmezett értéket ad a telitettsegnek és az elfogyasztottSporaknak.
     * @param tekton a kezdő tekton.
     */
    public Rovar(Tekton tekton, int ID) {
        this.tekton = tekton;
        this.telitettseg = 3;
        this.elfogyasztottSporak = new ArrayList<>();
        this.ID = ID;
        this.vaghate = true;
        this.sebesseg = 1;
    }

    /**
     * Visszaadja a rovar azonosítóját
     * @return a rovar azonosítója
     */
    public int getID() {
        return ID;
    }

    /**
     * Visszaadja a rovar aktuális tektonját
     * @return a rovar aktuális tektonja
     */
    public Tekton getTekton(){
        return tekton;
    }

    /**
     * Gombafonal elvágása
     * @brief A rovar elvágja az adott gombafonalat.
     * @param fonal a fonal, amit el kell vágni.
     */
    public void fonalElvagas(Gombafonal fonal) {
        if (!vaghate) {
            parancsFeldolgozo.print("Rovar ("+ID+") NEM elrágta Fonal ("+fonal.getID()+")\n");
            return;
        }

        Tekton t1 = fonal.getHatar1();
        Tekton t2 = fonal.getHatar2();

        if (t1 != tekton && t2 != tekton) {
            parancsFeldolgozo.print("Rovar ("+ID+") NEM elrágta Fonal ("+fonal.getID()+")\n");
            return;
        }

        parancsFeldolgozo.print("Rovar ("+ID+") elvágta Fonal ("+fonal.getID()+")\n");
        fonal.elragas();
    }

    /**
     * Spóra elfogyasztása
     * @brief A rovar elfogyaszt egy adott spórát.
     * @param spora a spóra, amit elfogyaszt.
     */
    public void elfogyaszt(Spora spora){
        telitettseg=3;
        parancsFeldolgozo.print("Rovar ("+ID+") elfogyasztotta Spóra ("+spora.getID()+")\n");
        elfogyasztottSporak.add(spora);
        parancsFeldolgozo.print("Rovar ("+ID+") elfogyasztottsporak értéke megváltozott: -> Spóra ("+spora.getID()+")\n");
        spora.hatasKifejtes(this);
    }

    /**
     * Rovar áttelepítése
     * @brief A rovar áttelepül a következő tektonra.
     * @param kovetkezo a következő tekton.
     */
    public void attesz(Tekton kovetkezo){
        boolean szomszedos = tekton.szomszedosTekton(kovetkezo);
        if (szomszedos) {
            parancsFeldolgozo.print("Rovar ("+ID+") tekton értéke megváltozott: Tekton ("+tekton.getID()+") -> Tekton ("+kovetkezo.getID()+")\n");
            setTekton(kovetkezo);
        } else {
            parancsFeldolgozo.print("Rovar ("+ID+") tekton értéke NEM változott: Tekton ("+tekton.getID()+")\n");
        }
    }

    /**
     * Beállítja a rovar tektonját, amin van.
     * @param tekton a beállítandó tekton.
     */
    public void setTekton(Tekton tekton) {
        this.tekton = tekton;
    }

    /**
     * Visszaadja a rovar telítettségét
     * @return a rovar telítettsége
     */
    public int getTelitettseg() {
        return telitettseg;
    }

    /**
     * Beállítja a rovar telítettségét
     * @param telitettseg a rovar telítettsége
     */
    public void setTelitettseg(int telitettseg) {
        this.telitettseg = telitettseg;
    }

    /**
     * Beállítja a rovar vágási lehetőségét
     * @return a rovar vágási lehetősége
     */
    public void setVaghate(boolean vaghate) {
        this.vaghate = vaghate;
    }

    /**
     * Visszaadja a rovar elfogyasztott spóráit
     * @return a rovar elfogyasztott spórái
     */
    public List<Spora> getElfogyasztottSporak() {
        return elfogyasztottSporak;
    }

    /**
     * Visszaállítja a rovart az eredeti állapotába
     */
    private void resetEffects(){
        sebesseg = 2;
        vaghate = true;
    }

    /**
     * Spórák hatásának kifejtése
     */
    public void sporaManager(){
        resetEffects();
        List<Spora> sporak = new ArrayList<>();
        for (Spora s : elfogyasztottSporak) {
            s.csokkentSzamlalo(1);
            if (s.getSzamlalo() == 0) {
                sporak.add(s);
                s.hatasKifejtes(this);
            } else {
                s.hatasKifejtes(this);
            }
        } if (sebesseg != 2) parancsFeldolgozo.print("Rovar (" + ID + ") sebesség értéke megváltozott: " + 2 + " -> " + sebesseg + "\n");
        if (!sporak.isEmpty()) {
            parancsFeldolgozo.print("Rovar (" + ID + ") elfogyasztottsporak értéke megváltozott: ");
            for (int i = 0; i < elfogyasztottSporak.size(); i++) parancsFeldolgozo.print("Spóra (" + elfogyasztottSporak.get(i).getID() + ")" + (i == elfogyasztottSporak.size() - 1 ? " " : ", "));
            parancsFeldolgozo.print("->");
            for (Spora s : sporak) {
                elfogyasztottSporak.remove(s);
            } for (int i = 0; i < elfogyasztottSporak.size(); i++) parancsFeldolgozo.print("Spóra (" + elfogyasztottSporak.get(i).getID() + ")" + (i == elfogyasztottSporak.size() - 1 ? "\n" : ","));
            parancsFeldolgozo.print("\n");
        }
    }

    /**
     * Pontlevonás
     */
    private void pontLevonas(Rovarasz rsz){
        rsz.setHatralevoAkciopont(rsz.getHatralevoAkciopont() - sebesseg);
    }

    /**
     * Beállítja a rovar sebességét
     * @param sebesseg a rovar sebessége
     */
    public void setSebesseg(int sebesseg) {
        this.sebesseg = sebesseg;
    }

    /**
     * Visszaadja a rovar sebességét
     * @return a rovar sebessége
     */
    public int getSebesseg() {
        return sebesseg;
    }

    /**
     * Visszaadja a rovar vágási lehetőségét
     * @return a rovar vágási lehetősége
     */
    public boolean isVaghate() {
        return vaghate;
    }
}
